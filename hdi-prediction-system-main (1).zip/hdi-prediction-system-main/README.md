# Human Development Index (HDI) Prediction Using Machine Learning

A modern, responsive, and professional web dashboard that predicts the Human Development Index (HDI) category of a country based on key socio-economic indicators. The application classifies countries into one of four categories: **Very High**, **High**, **Medium**, or **Low** Human Development.

Following the United Nations Development Programme (UNDP) framework, this system emphasizes that human development is determined not only by economic growth but also by health and education standards.

## 🌟 Features

- **ML Predictions & Confidence**: Utilizes a trained Random Forest Classifier to assign countries to HDI categories and outputs a model confidence percentage.
- **UN Dimension Indices**: Automatically calculates mathematical sub-indices for:
  - **Health Index** (from Life Expectancy)
  - **Education Index** (from Expected and Mean Years of Schooling)
  - **Income Index** (from GNI per Capita in PPP USD)
- **Glassmorphic UI**: Premium, dark-mode-adapted glassmorphism layout with fluid radial gradient background highlights.
- **Dynamic Policy Interventions**: Contextual recommendations for policy development based on specific indicator weaknesses.
- **Quick-Fill Presets**: Easy one-click buttons to load test scenarios (Very High, High, Medium, Low profiles).
- **Responsive Layout**: Designed for mobile, tablet, and desktop monitors.

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3 (Vanilla), Vanilla JavaScript, Lucide Icons
- **Backend**: Python Flask
- **Machine Learning**: Scikit-Learn (Random Forest)
- **Data Processing**: Pandas, NumPy
- **Model Serialization**: Pickle

---

## 🚀 Quick Start

### Prerequisites
Make sure you have Python 3.10+ and Git installed on your system.

### 1. Clone the repository / Open folder
Navigate to the directory where you want to run the project.

### 2. Set Up Virtual Environment & Install Dependencies
Initialize a virtual environment and install the required libraries:

```bash
# Create a virtual environment
python -m venv .venv

# Activate the virtual environment
# On Windows (PowerShell):
.venv\Scripts\Activate.ps1
# On macOS/Linux:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Train the Model
Generate the synthetic country dataset (built on UN mathematical formulas) and train the classifier:
```bash
python train_model.py
```
This will train the Random Forest Classifier, output accuracy metrics, and serialize the pipeline to `model.pkl`.

### 4. Run the Web Server
Launch the Flask development server:
```bash
python app.py
```

Open your browser and navigate to **[http://127.0.0.1:5000](http://127.0.0.1:5000)**.

---

## 🧪 Running Tests
To run the automated test suite confirming the prediction scenarios:
```bash
python test_api.py
```
