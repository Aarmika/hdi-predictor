import unittest
import json
from app import app, load_model

class TestHDIPredictionAPI(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        # Ensure the model is loaded before testing
        load_model()
        cls.client = app.test_client()

    def test_predict_very_high_hdi(self):
        # Scenario 1 - Predicting Very High Human Development
        payload = {
            "life_expectancy": 82.0,
            "mean_schooling": 13.0,
            "expected_schooling": 16.0,
            "gni_per_capita": 50000.0
        }
        response = self.client.post(
            '/predict',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        
        self.assertIn('predicted_category', data)
        self.assertEqual(data['predicted_category'], 'Very High')
        self.assertGreater(data['confidence'], 80)
        self.assertGreaterEqual(data['hdi_score'], 0.800)
        self.assertIn('health', data['indices'])
        self.assertIn('education', data['indices'])
        self.assertIn('income', data['indices'])
        self.assertIn('explanation', data)
        self.assertIn('recommendations', data)
        print("Scenario 1 (Very High HDI) verification passed!")

    def test_predict_medium_hdi(self):
        # Scenario 2 - Predicting Medium Human Development
        payload = {
            "life_expectancy": 68.0,
            "mean_schooling": 7.0,
            "expected_schooling": 11.0,
            "gni_per_capita": 8000.0
        }
        response = self.client.post(
            '/predict',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        
        self.assertEqual(data['predicted_category'], 'Medium')
        self.assertTrue(0.550 <= data['hdi_score'] < 0.700)
        self.assertIn('explanation', data)
        self.assertIn('recommendations', data)
        print("Scenario 2 (Medium HDI) verification passed!")

    def test_predict_low_hdi(self):
        # Scenario 3 - Assessing Countries Requiring Development Intervention (Low HDI)
        payload = {
            "life_expectancy": 53.0,
            "mean_schooling": 3.0,
            "expected_schooling": 6.0,
            "gni_per_capita": 1500.0
        }
        response = self.client.post(
            '/predict',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        
        self.assertEqual(data['predicted_category'], 'Low')
        self.assertLess(data['hdi_score'], 0.550)
        self.assertIn('explanation', data)
        self.assertIn('recommendations', data)
        print("Scenario 3 (Low HDI) verification passed!")

    def test_invalid_input_ranges(self):
        # Test out-of-bounds validations
        payload = {
            "life_expectancy": 15.0,  # Below 20
            "mean_schooling": 8.0,
            "expected_schooling": 12.0,
            "gni_per_capita": 15000.0
        }
        response = self.client.post(
            '/predict',
            data=json.dumps(payload),
            content_type='application/json'
        )
        self.assertEqual(response.status_code, 400)
        data = json.loads(response.data)
        self.assertIn('error', data)
        print("Invalid Life Expectancy input handling passed!")

if __name__ == '__main__':
    unittest.main()
