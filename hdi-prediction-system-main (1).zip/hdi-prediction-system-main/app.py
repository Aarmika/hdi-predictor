import os
import pickle
import numpy as np
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Global variables for model and scaler
model = None
scaler = None
categories_map = {0: "Very High", 1: "High", 2: "Medium", 3: "Low"}

def load_model():
    global model, scaler
    model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')
    if os.path.exists(model_path):
        with open(model_path, 'rb') as f:
            data = pickle.load(f)
            model = data['model']
            scaler = data['scaler']
            print("Successfully loaded model from model.pkl")
    else:
        print("Warning: model.pkl not found. Please run train_model.py first.")

# Try to load model at start
load_model()

def calculate_dimensions(life_exp, mean_school, exp_school, gni):
    # Standard UN HDI Index formulas
    # Health Index (Life Expectancy Index)
    health_idx = (life_exp - 20.0) / (85.0 - 20.0)
    health_idx = float(np.clip(health_idx, 0.0, 1.0))
    
    # Education Index
    mys_idx = mean_school / 15.0
    mys_idx = np.clip(mys_idx, 0.0, 1.0)
    eys_idx = exp_school / 18.0
    eys_idx = np.clip(eys_idx, 0.0, 1.0)
    edu_idx = float((mys_idx + eys_idx) / 2.0)
    
    # Income Index
    gni_clipped = np.clip(gni, 100.0, 75000.0)
    income_idx = (np.log(gni_clipped) - np.log(100.0)) / (np.log(75000.0) - np.log(100.0))
    income_idx = float(np.clip(income_idx, 0.0, 1.0))
    
    # Mathematical HDI Score
    eps = 1e-7
    hdi = float((np.maximum(health_idx, eps) * np.maximum(edu_idx, eps) * np.maximum(income_idx, eps)) ** (1.0/3.0))
    
    return {
        'health_index': round(health_idx, 3),
        'education_index': round(edu_idx, 3),
        'income_index': round(income_idx, 3),
        'hdi_score': round(hdi, 3)
    }

def generate_recommendations(indices, life_exp, mean_school, exp_school, gni):
    rec = []
    
    # Health index recommendations
    if indices['health_index'] < 0.55:
        rec.append({
            'area': 'Health',
            'severity': 'high',
            'icon': 'heart-pulse',
            'message': f"Life expectancy ({life_exp} years) is low. Prioritize expanding access to primary healthcare, clean drinking water, immunization programs, and maternal care."
        })
    elif indices['health_index'] < 0.70:
        rec.append({
            'area': 'Health',
            'severity': 'medium',
            'icon': 'heart-pulse',
            'message': f"Life expectancy ({life_exp} years) is moderate. Target reducing non-communicable diseases, upgrading hospital infrastructure, and enhancing healthcare coverage."
        })
    else:
        rec.append({
            'area': 'Health',
            'severity': 'low',
            'icon': 'heart-pulse',
            'message': f"Health indicators are strong. Focus on maintaining quality of care, healthy aging initiatives, and advanced medical research."
        })

    # Education index recommendations
    if indices['education_index'] < 0.55:
        rec.append({
            'area': 'Education',
            'severity': 'high',
            'icon': 'graduation-cap',
            'message': f"Education levels are critical (Mean: {mean_school} yrs, Expected: {exp_school} yrs). Invest in school infrastructure, recruit trained teachers, and eliminate tuition barriers to improve enrollment."
        })
    elif indices['education_index'] < 0.75:
        rec.append({
            'area': 'Education',
            'severity': 'medium',
            'icon': 'graduation-cap',
            'message': f"Education levels are moderate. Focus on secondary school completion, expanding vocational/technical training, and aligning curricula with modern job markets."
        })
    else:
        rec.append({
            'area': 'Education',
            'severity': 'low',
            'icon': 'graduation-cap',
            'message': f"Education index is high. Maintain funding for universities, encourage lifelong learning, and foster research and development (R&D)."
        })

    # Income index recommendations
    if indices['income_index'] < 0.55:
        rec.append({
            'area': 'Economy',
            'severity': 'high',
            'icon': 'briefcase',
            'message': f"Economic output (GNI per capita: ${gni:,.0f}) is low. Stimulate growth by investing in infrastructure, promoting basic industries, and supporting agriculture and small businesses."
        })
    elif indices['income_index'] < 0.75:
        rec.append({
            'area': 'Economy',
            'severity': 'medium',
            'icon': 'briefcase',
            'message': f"Economic indicators are moderate. Diversify the economy away from raw materials, foster innovation, support digital transformation, and strengthen financial institutions."
        })
    else:
        rec.append({
            'area': 'Economy',
            'severity': 'low',
            'icon': 'briefcase',
            'message': f"Economic performance is robust. Focus on sustainable development, reducing income inequality, and investing in green and high-tech sectors."
        })
        
    return rec

def generate_narrative(category, indices):
    h = indices['health_index']
    e = indices['education_index']
    i = indices['income_index']
    
    weakest_score = min(h, e, i)
    weakest_area = ""
    if weakest_score == h:
        weakest_area = "healthcare and life expectancy"
    elif weakest_score == e:
        weakest_area = "education and school attainment"
    else:
        weakest_area = "gross national income (GNI) per capita"
        
    strongest_score = max(h, e, i)
    strongest_area = ""
    if strongest_score == h:
        strongest_area = "health systems and longevity"
    elif strongest_score == e:
        strongest_area = "educational standards"
    else:
        strongest_area = "economic performance (GNI)"
        
    if category == "Very High":
        return f"This country demonstrates exemplary socio-economic performance. Development is balanced across all sectors, with {strongest_area} acting as a standout strength. There are no major developmental bottlenecks, placing this nation in the top tier globally."
    elif category == "High":
        return f"The country exhibits solid development foundations. However, full potential is hindered by limitations in {weakest_area}. Targeted improvements in this bottleneck can elevate the nation to Very High human development status."
    elif category == "Medium":
        return f"This country shows moderate development. While there are positive trends in {strongest_area}, significant structural gaps remain in {weakest_area}. Balanced policy interventions in education, health, and economic diversification are required."
    else: # Low
        return f"This nation faces severe developmental challenges. High-priority interventions are needed across the board, particularly addressing {weakest_area}, which represents a critical bottleneck to basic human well-being."

@app.route('/')
def home():
    # If model is not loaded yet, try to load it
    global model
    if model is None:
        load_model()
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    global model, scaler
    if model is None or scaler is None:
        load_model()
        if model is None:
            return jsonify({'error': 'Machine learning model is not available. Please train it first.'}), 500
            
    try:
        data = request.get_json()
        
        # Extract and validate inputs
        life_exp = float(data.get('life_expectancy', 0))
        mean_school = float(data.get('mean_schooling', 0))
        exp_school = float(data.get('expected_schooling', 0))
        gni = float(data.get('gni_per_capita', 0))
        
        # Validations
        if not (20 <= life_exp <= 95):
            return jsonify({'error': 'Life Expectancy must be between 20 and 95 years.'}), 400
        if not (0 <= mean_school <= 20):
            return jsonify({'error': 'Mean Years of Schooling must be between 0 and 20 years.'}), 400
        if not (0 <= exp_school <= 25):
            return jsonify({'error': 'Expected Years of Schooling must be between 0 and 25 years.'}), 400
        if not (100 <= gni <= 150000):
            return jsonify({'error': 'GNI per Capita must be between $100 and $150,000.'}), 400
            
        # Calculate sub-indices and mathematical HDI
        dim_data = calculate_dimensions(life_exp, mean_school, exp_school, gni)
        
        # Machine learning prediction
        features = np.array([[life_exp, mean_school, exp_school, gni]])
        features_scaled = scaler.transform(features)
        
        # Get category prediction
        cat_code = int(model.predict(features_scaled)[0])
        category = categories_map[cat_code]
        
        # Get confidence score
        probabilities = model.predict_proba(features_scaled)[0]
        confidence = float(probabilities[cat_code])
        
        # Generate explanations and recommendations
        explanation = generate_narrative(category, dim_data)
        recommendations = generate_recommendations(dim_data, life_exp, mean_school, exp_school, gni)
        
        return jsonify({
            'predicted_category': category,
            'confidence': round(confidence * 100, 1),
            'hdi_score': dim_data['hdi_score'],
            'indices': {
                'health': dim_data['health_index'],
                'education': dim_data['education_index'],
                'income': dim_data['income_index']
            },
            'explanation': explanation,
            'recommendations': recommendations
        })
        
    except ValueError as e:
        return jsonify({'error': f'Invalid input values: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'error': f'An unexpected error occurred: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
