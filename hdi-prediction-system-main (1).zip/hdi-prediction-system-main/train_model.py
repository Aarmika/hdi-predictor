import numpy as np
import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

def calculate_hdi(life_exp, mean_school, exp_school, gni):
    # Life Expectancy Index (LEI)
    # Bounds: 20 to 85
    lei = (life_exp - 20.0) / (85.0 - 20.0)
    lei = np.clip(lei, 0.0, 1.0)
    
    # Mean Years of Schooling Index (MYSI)
    # Bounds: 0 to 15
    mysi = mean_school / 15.0
    mysi = np.clip(mysi, 0.0, 1.0)
    
    # Expected Years of Schooling Index (EYSI)
    # Bounds: 0 to 18
    eysi = exp_school / 18.0
    eysi = np.clip(eysi, 0.0, 1.0)
    
    # Education Index (EI)
    ei = (mysi + eysi) / 2.0
    
    # Income Index (II)
    # Bounds: 100 to 75,000 (standard log formulation)
    # GNI values below 100 are clipped to 100, above 75,000 clipped to 75,000
    gni_clipped = np.clip(gni, 100.0, 75000.0)
    ii = (np.log(gni_clipped) - np.log(100.0)) / (np.log(75000.0) - np.log(100.0))
    ii = np.clip(ii, 0.0, 1.0)
    
    # HDI (Geometric Mean)
    # Use small epsilon to prevent cube root of 0 from causing issues
    eps = 1e-7
    hdi = (np.maximum(lei, eps) * np.maximum(ei, eps) * np.maximum(ii, eps)) ** (1.0 / 3.0)
    
    return hdi

def get_hdi_category(hdi):
    if hdi >= 0.800:
        return 0  # Very High
    elif hdi >= 0.700:
        return 1  # High
    elif hdi >= 0.550:
        return 2  # Medium
    else:
        return 3  # Low

def main():
    print("Generating synthetic country data based on UN HDI formula...")
    np.random.seed(42)
    n_samples = 15000
    
    # Generate realistic indicator distributions that cover the whole spectrum
    # We will generate a mix of uniform distributions to ensure equal coverage of all categories
    life_exp = np.random.uniform(30.0, 87.0, n_samples)
    mean_school = np.random.uniform(0.0, 16.0, n_samples)
    exp_school = np.random.uniform(0.0, 20.0, n_samples)
    # GNI per capita follows a log-uniform distribution to cover ranges from 100 to 100,000
    gni = np.exp(np.random.uniform(np.log(100), np.log(100000), n_samples))
    
    # Calculate HDI scores and categories
    hdi_scores = calculate_hdi(life_exp, mean_school, exp_school, gni)
    categories = np.array([get_hdi_category(h) for h in hdi_scores])
    
    # Create DataFrame
    df = pd.DataFrame({
        'life_exp': life_exp,
        'mean_school': mean_school,
        'exp_school': exp_school,
        'gni': gni,
        'hdi_score': hdi_scores,
        'category': categories
    })
    
    # Print distribution
    cat_names = {0: "Very High", 1: "High", 2: "Medium", 3: "Low"}
    print("\nDataset Category Distribution:")
    for cat_val, name in cat_names.items():
        count = np.sum(df['category'] == cat_val)
        print(f"  {name}: {count} ({count/n_samples*100:.2f}%)")
        
    # Prepare features and target
    X = df[['life_exp', 'mean_school', 'exp_school', 'gni']].values
    y = df['category'].values
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # Standardize features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train Random Forest Classifier
    print("\nTraining RandomForestClassifier...")
    clf = RandomForestClassifier(n_estimators=100, max_depth=15, min_samples_split=4, random_state=42)
    clf.fit(X_train_scaled, y_train)
    
    # Evaluate
    y_pred = clf.predict(X_test_scaled)
    acc = accuracy_score(y_test, y_pred)
    print(f"Test Set Accuracy: {acc*100:.4f}%")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=["Very High", "High", "Medium", "Low"]))
    
    # Save the model, scaler, and configuration
    model_data = {
        'model': clf,
        'scaler': scaler,
        'feature_names': ['life_exp', 'mean_school', 'exp_school', 'gni'],
        'categories_map': {0: "Very High", 1: "High", 2: "Medium", 3: "Low"}
    }
    
    with open('model.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    print("Model serialized and saved successfully to 'model.pkl'")

if __name__ == '__main__':
    main()
