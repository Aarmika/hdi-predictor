document.addEventListener('DOMContentLoaded', () => {
    // Initialize Lucide Icons
    lucide.createIcons();

    // Elements
    const form = document.getElementById('hdi-form');
    const predictBtn = document.getElementById('predict-btn');
    const resetBtn = document.getElementById('reset-btn');
    const placeholder = document.getElementById('results-placeholder');
    const resultsContent = document.getElementById('results-content');
    
    // Sliders & Number inputs
    const inputs = [
        { slider: 'life_expectancy_slider', number: 'life_expectancy' },
        { slider: 'expected_schooling_slider', number: 'expected_schooling' },
        { slider: 'mean_schooling_slider', number: 'mean_schooling' },
        { slider: 'gni_per_capita_slider', number: 'gni_per_capita' }
    ];

    // Synchronize sliders and numbers
    inputs.forEach(pair => {
        const sliderEl = document.getElementById(pair.slider);
        const numberEl = document.getElementById(pair.number);

        // Slider input updates number
        sliderEl.addEventListener('input', (e) => {
            numberEl.value = parseFloat(e.target.value).toFixed(pair.number === 'gni_per_capita' ? 0 : 1);
        });

        // Number input updates slider
        numberEl.addEventListener('input', (e) => {
            let val = parseFloat(e.target.value);
            if (!isNaN(val)) {
                sliderEl.value = val;
            }
        });
    });

    // Reset action
    resetBtn.addEventListener('click', () => {
        form.reset();
        
        // Reset sliders explicitly since form.reset() doesn't always trigger input events
        inputs.forEach(pair => {
            const numberEl = document.getElementById(pair.number);
            const sliderEl = document.getElementById(pair.slider);
            sliderEl.value = numberEl.value;
        });

        // Hide results, show placeholder
        resultsContent.classList.add('hidden');
        placeholder.classList.remove('hidden');
    });

    // Form Submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Form values
        const life_expectancy = parseFloat(document.getElementById('life_expectancy').value);
        const expected_schooling = parseFloat(document.getElementById('expected_schooling').value);
        const mean_schooling = parseFloat(document.getElementById('mean_schooling').value);
        const gni_per_capita = parseFloat(document.getElementById('gni_per_capita').value);

        // Visual loading state
        predictBtn.disabled = true;
        predictBtn.innerHTML = `<i data-lucide="loader-2" class="animate-spin"></i> Predicting...`;
        lucide.createIcons();

        try {
            const response = await fetch('/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    life_expectancy,
                    expected_schooling,
                    mean_schooling,
                    gni_per_capita
                })
            });

            const data = await response.get_json ? await response.get_json() : await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Prediction failed');
            }

            displayResults(data);
        } catch (error) {
            alert(`Error: ${error.message}`);
        } finally {
            predictBtn.disabled = false;
            predictBtn.innerHTML = `<i data-lucide="activity"></i> Predict HDI Category`;
            lucide.createIcons();
        }
    });

    // Animate and render prediction output
    function displayResults(data) {
        // Toggle view
        placeholder.classList.add('hidden');
        resultsContent.classList.remove('hidden');

        // Clean previous theme classes from header card
        const headerCard = document.getElementById('result-header-card');
        headerCard.className = 'result-header-card glass-card'; // reset classes
        
        // Add new theme class based on predicted category
        const category = data.predicted_category;
        const themeClass = 'theme-' + category.toLowerCase().replace(' ', '-');
        headerCard.classList.add(themeClass);

        // Update Text Elements
        document.getElementById('result-category-title').innerText = category + ' Development';
        document.getElementById('result-hdi-score').innerText = data.hdi_score.toFixed(3);
        document.getElementById('narrative-text').innerText = data.explanation;

        // Animate Model Confidence Circle Gauge
        const confidenceRing = document.getElementById('confidence-ring');
        const radius = confidenceRing.r.baseVal.value;
        const circumference = radius * 2 * Math.PI;
        
        confidenceRing.style.strokeDasharray = `${circumference} ${circumference}`;
        confidenceRing.style.strokeDashoffset = circumference;
        
        // Trigger reflow to ensure animation runs
        confidenceRing.getBoundingClientRect();
        
        const confidenceVal = data.confidence;
        document.getElementById('confidence-value').innerText = confidenceVal;
        
        const offset = circumference - (confidenceVal / 100) * circumference;
        confidenceRing.style.strokeDashoffset = offset;

        // Update Progress Bars & Text Values (Indices)
        const updateProgressBar = (barId, valId, score) => {
            const bar = document.getElementById(barId);
            const valSpan = document.getElementById(valId);
            
            valSpan.innerText = score.toFixed(3);
            bar.style.width = '0%';
            
            setTimeout(() => {
                bar.style.width = `${score * 100}%`;
            }, 50);
        };

        updateProgressBar('health-index-bar', 'health-index-value', data.indices.health);
        updateProgressBar('education-index-bar', 'education-index-value', data.indices.education);
        updateProgressBar('income-index-bar', 'income-index-value', data.indices.income);

        // Render Recommendations List
        const recListContainer = document.getElementById('recommendations-list');
        recListContainer.innerHTML = ''; // Clear existing
        
        data.recommendations.forEach(rec => {
            const item = document.createElement('div');
            item.className = 'recommendation-item';
            
            // Map Lucide icons based on area
            let iconName = 'help-circle';
            if (rec.area === 'Health') iconName = 'heart-pulse';
            if (rec.area === 'Education') iconName = 'graduation-cap';
            if (rec.area === 'Economy') iconName = 'briefcase';

            item.innerHTML = `
                <div class="rec-icon-wrapper severity-${rec.severity}">
                    <i data-lucide="${iconName}"></i>
                </div>
                <div class="rec-content">
                    <div class="rec-title-row">
                        <h4>${rec.area} Policy Interventions</h4>
                        <span class="rec-badge ${rec.severity}">${rec.severity} priority</span>
                    </div>
                    <p>${rec.message}</p>
                </div>
            `;
            recListContainer.appendChild(item);
        });

        // Re-initialize dynamic Lucide icons
        lucide.createIcons();
    }
});

// Global Function to load presets (called inline from HTML buttons)
window.loadPreset = (lifeExp, expSchool, meanSchool, gni) => {
    // Set Slider & Input values
    document.getElementById('life_expectancy').value = lifeExp;
    document.getElementById('life_expectancy_slider').value = lifeExp;

    document.getElementById('expected_schooling').value = expSchool;
    document.getElementById('expected_schooling_slider').value = expSchool;

    document.getElementById('mean_schooling').value = meanSchool;
    document.getElementById('mean_schooling_slider').value = meanSchool;

    document.getElementById('gni_per_capita').value = gni;
    document.getElementById('gni_per_capita_slider').value = gni;

    // Trigger prediction form submission programmatically
    const submitBtn = document.getElementById('predict-btn');
    submitBtn.click();
};
